﻿using refactor_this.Helpers;
using refactor_this.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace refactor_this.Core
{
    public class Products
    {
        public List<Product> Items { get; private set; }

        // Constructor will get ALL products
        public Products()
        {
            LoadProducts(null);
        }

        // Get a product by product name
        public Products(string name)
        {
            LoadProducts($"where lower(name) like '%{name.ToLower()}%'");
        }

        // Get a specific product (eg by Name or ID)
        private void LoadProducts(string where)
        {
            Items = new List<Product>();
            var conn = DBConnectionHelpers.NewConnection();
            var cmd = new SqlCommand($"select id from product {where}", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                var id = Guid.Parse(rdr["id"].ToString());
                Items.Add(new Product(id));
            }
        }
    }

}