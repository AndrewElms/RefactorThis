﻿using refactor_this.Helpers;
using refactor_this.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace refactor_this.Core
{
    public class ProductOptions
    {
        public List<ProductOption> Items { get; private set; }

        // Constructor will get all options for all products
        public ProductOptions()
        {
           // LoadProductOptions(null);         // ToDo: Remove, not used
        }

        // Get all product options for a specific product
        public ProductOptions(Guid productId)
        {
            LoadProductOptions($"where productid = '{productId}'");
        }

        // Get the options for a product (eg by Name or ID)
        private void LoadProductOptions(string where)
        {
            Items = new List<ProductOption>();
            var conn = DBConnectionHelpers.NewConnection();
            var cmd = new SqlCommand($"select id from productoption {where}", conn);
            conn.Open();

            var rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                var id = Guid.Parse(rdr["id"].ToString());
                Items.Add(new ProductOption(id));
            }
        }
    }
}
