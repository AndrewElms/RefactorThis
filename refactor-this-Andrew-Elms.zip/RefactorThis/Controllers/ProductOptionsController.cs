﻿using refactor_this.Core;
using refactor_this.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace refactor_this.Controllers
{
    [RoutePrefix("products/{productId}/options")]
    public class ProductOptionsController : ApiController
    {

        [Route]
        [HttpGet]
        // GET /products/{id}/options` - finds all options for a specified product.
        public ProductOptions GetOptions(Guid productId)
        {
           return new ProductOptions(productId);
        }

        [Route("{id}")]
        [HttpGet]
        // GET /products/{id}/options/{optionId}` - finds the specified product option for the specified product.
        public ProductOption GetOption(Guid productId, Guid id)
        {
            var option = new ProductOption(id);
            if (option.IsNew)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            return option;
        }

        [Route]
        [HttpPost]
        // POST /products/{id}/options` - adds a new product option to the specified product.
        public void CreateOption(Guid productId, ProductOption option)
        {
            option.ProductId = productId;
            option.Save();
        }

        [Route("{id}")]
        [HttpPut]
        // PUT /products/{id}/options/{optionId}` - updates the specified product option.
        public void UpdateOption(Guid id, ProductOption option)
        {
            var orig = new ProductOption(id)
            {
                Name = option.Name,
                Description = option.Description
            };

            if (!orig.IsNew)
                orig.Save();
        }

        [Route("{id}")]
        [HttpDelete]
        // DELETE /products/{id}/options/{optionId}` - deletes the specified product option.
        public void DeleteOption(Guid id)
        {
            var opt = new ProductOption(id);
            opt.Delete();
        }
    }
}
