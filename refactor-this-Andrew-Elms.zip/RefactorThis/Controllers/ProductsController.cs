﻿using System;
using System.Net;
using System.Web.Http;
using refactor_this.Models;
using refactor_this.Core;

namespace refactor_this.Controllers
{

    [RoutePrefix("products")]
    public class ProductsController : ApiController
    {
        [Route]
        [HttpGet]
        //`GET /products` - gets all products.
        public Products GetAll()
        {
            return new Products();
        }

        [Route]
        [HttpGet]
        //GET /products?name={name}` - finds all products matching the specified name.
        public Products SearchByName(string name)
        {
            return new Products(name);
        }

        [Route("{id}")]
        [HttpGet]
        // GET /products/{id}` - gets the project that matches the specified ID - ID is a GUID.
        public Product GetProduct(Guid id)
        {
            var product = new Product(id);
            if (product.IsNew)
                throw new HttpResponseException(HttpStatusCode.NotFound);

            return product;
        }

        [Route]
        [HttpPost]
        // POST /products` - creates a new product.
        public void Create(Product product)
        {           
            product.Save();
        }

        [Route("{id}")]
        [HttpPut]
        // PUT /products/{id}` - updates a product.
        public void Update(Guid id, Product product)
        {
            var orig = new Product(id)
            {
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                DeliveryPrice = product.DeliveryPrice
            };

            if (!orig.IsNew)
                orig.Save();
        }

        [Route("{id}")]
        [HttpDelete]
        // DELETE /products/{id}` - deletes a product and its options.
        public void Delete(Guid id)
        {
            var product = new Product(id);
            product.Delete();
        }

    }
}
